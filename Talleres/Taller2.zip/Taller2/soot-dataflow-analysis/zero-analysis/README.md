[Soot](https://github.com/Sable/soot) division by zero anaylisis, using data-flow techniques
